The source file option_bits.c contains the PFL option bits mappings.  Set
appropriate values in that file for the USER EDIT lines and then compile the
option bits programming file by running the create-pfl-option-bits.sh script.

The resultant dot-flash file can be programmed into flash using the nios2 flash
programmer utility.
